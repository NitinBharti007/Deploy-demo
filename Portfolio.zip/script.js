var typed = new Typed(".typing", {
    strings: ["","Frontend Web Developer", "Youtuber"],
    typeSpeed: 100,
    BackSpeed: 60,
    loop:true
})
  